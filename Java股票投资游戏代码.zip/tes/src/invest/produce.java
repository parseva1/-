package invest;

import java.util.Scanner;

public class produce {
    public void s(money m){
        while (true){
            if (m.InvestMoney <= 0){
                System.out.println("钱赔光了！大笨蛋！退出模拟程序");
                System.exit(0);
            } else if (m.InvestMoney > 0){
                System.out.println("是否模拟投资？按1继续，按0退出模拟");
                Scanner s = new Scanner(System.in);
                int state = s.nextInt();
                if (state == 0){
                    System.out.println("退出模拟程序");
                    System.exit(0);
                }else if(state == 1){
                    Link(m);
                    if (m.InvestMoney > 100000){
                        System.out.println("恭喜你获得了十倍模拟收益，模拟结束！");
                        System.exit(0);
                    }
                }
            }
        }
    }

    public void Link(money m){
        windows w = new windows();
        w.start(m);
        w.limit(m);
        w.math(m);
        w.result(m);
    }
}
