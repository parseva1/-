//import java.util.Random;
//import java.util.Scanner;
//
//public class StockInvestment{
//    public static void main(String args[]){
//
//        //股价
//        int price = 10;
//        //输入函数
//        Scanner s = new Scanner(System.in);
//        System.out.println("==股票投资模拟==");
//        System.out.println("新股的股票价格是"+price);
//        System.out.println("请输入买入量（买入量为10-10000000，为10的倍数,比如1500）");
//        //接收键盘上的值
//        int num = s.nextInt();
//        //非法判断边界，小于十，尾数不为0，大于千万的数字非法
//        if(num < 10){
//            System.out.println("买入量非法，程序退出");
//            System.exit(0);
//        }
//        if ((num % 10) != 0){
//            System.out.println("买入量非法，程序退出");
//            System.exit(0);
//        }
//        if (num > 10000000){
//            System.out.println("买入量非法，程序退出");
//            System.exit(0);
//        }
////      买了多少股
//        int g = num/price;
//        System.out.println("买入了"+g+"股");
//        System.out.print("一周过去了..");
//        //随机数
//        Random r = new Random();
//        Boolean b = r.nextBoolean();
//        //判断正负，正，股价涨，负，股价跌
//        if (b){
//            price = price + r.nextInt(9);
//        }else{
//            price = price - r.nextInt(9);
//        }
//        System.out.println("股票价格是.."+price+"元!");
//        System.out.println(" ");
//        //上涨输出盈利，下跌输出亏损值
//        if(price >= 10){
//            System.out.println("你盈利了"+(price-10)*g+"元!");
//            System.out.println("现在总资产是"+price*g+"元!");
//        }else if (price < 10){
//            System.out.println("你亏损了"+(10-price)*g+"元!");
//            System.out.println("现在总资产是"+price*g+"元!");
//        }
//    }
//}
