package 纯java代码.invest;

import java.util.Random;
import java.util.Scanner;

public class main{
    public static void main(String args[]){
        money m = new money();
        produce p = new produce();
        p.s(m);
    }
}
