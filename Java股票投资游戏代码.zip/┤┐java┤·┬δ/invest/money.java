package 纯java代码.invest;

import java.util.Random;

public class money{
    int InvestMoney = 10000;
    int price = 10;
    int Stack = 0;
    int num = 0;

    public int getStack(int num){
        Stack = num/price;
        return Stack;
    }

    public int getInvestMoney(){
        if(price >= 10){
            InvestMoney = InvestMoney + (price-10)*Stack;
        }else if (price < 10){
            InvestMoney = InvestMoney - ((10-price)*Stack);
        }
        return InvestMoney;
    }

    public int getPrice(Random r,Boolean b){
        if (b){
            this.price = this.price + r.nextInt(9);
        }else{
            this.price = this.price - r.nextInt(9);
        }
        return price;
    }
}