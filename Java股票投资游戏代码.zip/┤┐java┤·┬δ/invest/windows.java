package 纯java代码.invest;

import javax.swing.*;
import java.util.Random;
import java.util.Scanner;

public class windows {
    Scanner s = new Scanner(System.in);

    public void start(money m){
        System.out.println("====================");
        System.out.println("==股票投资模拟==");
        System.out.println("新股的股票价格是"+m.price);
        System.out.println("目前总资产是"+m.InvestMoney);
        System.out.println("请输入投资额（↑小于总资产，不超过100000）比如："+m.InvestMoney/20*10);
        m.num = s.nextInt();
        if (m.num > m.InvestMoney){
            System.out.println("你没这么多钱呀！请重新输入投资额度");
            System.out.println("");
            start(m);
        }
        m.Stack = m.getStack(m.num);
    }

    public void limit(money m){
        if(m.num < 0){
            System.out.println("买的量太少了，程序退出");
            System.exit(0);
        }
        if ((m.num % 10) != 0){
            m.num = m.num - (m.num%10) - 1;
        }
        if (m.num > 100000){
            System.out.println("买的量太多了，程序退出");
            System.exit(0);
        }
        //买入多少股
        m.Stack = m.getStack(m.num);
        System.out.println("买入了"+m.Stack+"股");
        System.out.println(" ");
    }

    public void math(money m){
        //股票价格模拟计算
        Random r = new Random();
        Boolean b = r.nextBoolean();
        m.price = m.getPrice(r,b);
    }

    public void result(money m){
        System.out.print("一周过去了..");
        System.out.println("股票价格是.."+m.price+"元!");
        if(m.price >= 10){
            System.out.println("你盈利了"+(m.price-10)*m.Stack+"元!");
            System.out.println("现在总资产是"+m.getInvestMoney()+"元!");
        }else if (m.price < 10){
            System.out.println("你亏损了"+(10-m.price)*m.Stack+"元!");
            System.out.println("现在总资产是"+m.getInvestMoney()+"元!");
            produce p = new produce();
            p.s(m);
        }
    }
}
